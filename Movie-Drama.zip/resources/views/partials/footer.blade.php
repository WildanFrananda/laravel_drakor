<footer id="footer" class="footer">
    <div class="container">
      <div class="credits">
        Designed by DrakorZone</a>
      </div>
    </div>
  </footer><!-- End Footer -->