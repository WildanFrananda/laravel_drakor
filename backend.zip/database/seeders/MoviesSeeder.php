<?php

namespace Database\Seeders;

use App\Models\Movie;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class MoviesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Movie::create([
            'title' => 'Move to Heaven',
            'poster' => 'movetoheaven.jgp',
            'genre_id' => 1,
            'synopsys' => 'Han Geu Roo is an autistic 20-year-old. He works for his father’s business “Move To Heaven,” a company that specializes in crime scene cleanup, where they also collect and arrange items left by deceased people, and deliver them to the bereaved family.',
            'release_date' => '2021-05-14',
            'countries_id' => 1,
            'rating' => 9.2,
        ]);
    }
}