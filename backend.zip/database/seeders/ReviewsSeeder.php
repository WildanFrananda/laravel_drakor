<?php

namespace Database\Seeders;

use App\Models\Review;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ReviewsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Review::create([
            'movie_id' => 1,
            'user_id' => 1,
            'date' => '2021-05-14',
            'description' => 'This is a great movie!',
            'rating' => 9.2,
        ]);
    }
}
